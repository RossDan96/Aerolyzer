import test_wavelength

test_wavelength.test_all()
